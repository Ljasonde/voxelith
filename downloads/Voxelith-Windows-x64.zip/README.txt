Voxelith | Windows x64
Extract the entire archive, then launch Voxelith.exe. Requires a Vulkan 1.3 graphics driver.
Select New expedition. Collect one core from each ruin with the right mouse button.
Return to the purple gateway on the spawn island after collecting all three.
WASD move, mouse look, Shift sprint, Space jump, F flight, Ctrl descend.
Left click to mine, right click to build, 1-9 or wheel to select a block.
Esc pauses and saves. F2 hides the HUD and freezes time. F3 displays frame statistics.
Settings includes ray tracing, GPU culling, shadows, render scale and view distance.
Benchmark: Voxelith.exe --present --benchmark benchmarks/window --width 1920 --height 1080
4K image: Voxelith.exe --capture captures/spire.png --width 3840 --height 2160
Source, documentation, raw benchmark data and film: https://github.com/Ljasonde/voxelith
